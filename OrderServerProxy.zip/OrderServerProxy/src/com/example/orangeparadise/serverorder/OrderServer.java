package com.example.orangeparadise.serverorder;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketException;
import java.util.ArrayList;
import java.util.Enumeration;

public class OrderServer{
	private static final int PORT = 4040;
	private static final String ORDER = "order";
	private static final String REFRESH = "refresh";
	
	private static final String HOST_ADDR = "http://192.168.1.13:3333/";
	
	private OrderJsonReader reader;
	
	private ArrayList<Item> getItems() {
		ArrayList<Item> items = new ArrayList<>();
		
		items.add(new Item("Burger", 5.50, "Gourmet special burger", 
				HOST_ADDR +"image_burger.png"));
		items.add(new Item("Chicken", 6.00, "Fried tender, wings or leg",
				HOST_ADDR + "image_fried_chicken.png"));
		items.add(new Item("French Fries", 2.00, "Small pieces", 
				HOST_ADDR + "image_french_fries.png"));
		items.add(new Item("Onion Rings", 2.50, "Well fried onion rings", 
				HOST_ADDR + "image_onion_rings.png"));
		items.add(new Item("New", 0.65, "Test", HOST_ADDR + "image_onion_rings.png"));
		return items;
	}
	
	private String getItemJson() {
		ArrayList<Item> items = getItems();
		
		String itemJson = "[";
		
		for (int i = 0; i < items.size(); i++) {
			itemJson += items.get(i).toString();
			itemJson += ",";
		}
		
		itemJson += "]";
		
		return itemJson;
	}
	
	public void init() {
		reader = new OrderJsonReader(getItems());
		try {
			ServerSocket serverSocket = new ServerSocket(PORT);
			System.out.println(getIpAddress());
			while (true) {
				Socket client = serverSocket.accept();
				System.out.println("Client connected");
				System.out.println(client.getPort());
				new HandleThread(client);
			}
		} catch (Exception e) {
			System.out.println("Server Error");
			e.printStackTrace();
		}
	}
	
	private String getIpAddress() {
		String ip = "";
		
		try {
            Enumeration<NetworkInterface> enumNetworkInterfaces =
                    NetworkInterface.getNetworkInterfaces();
            while (enumNetworkInterfaces.hasMoreElements()){
                NetworkInterface networkInterface = enumNetworkInterfaces.nextElement();
                Enumeration<InetAddress> enumInetAddress = networkInterface.getInetAddresses();
                while (enumInetAddress.hasMoreElements()){
                    InetAddress inetAddress = enumInetAddress.nextElement();
                    if (inetAddress.isSiteLocalAddress()){
                        ip += "SiteLocalAddress: " + inetAddress.getHostAddress() + "\n";
                    }
                }
            }
        } catch (SocketException e) {
            e.printStackTrace();
            ip += "SomethingWrong! " + e.toString() + "\n";
        }

        return ip;
	}
	
	private class HandleThread implements Runnable{
		private Socket socket;
		
		public HandleThread(Socket client) {
			this.socket = client;
			new Thread(this).start();
		}

		@Override
		public void run() {
			try {
				DataInputStream inputStream = new 
						DataInputStream(socket.getInputStream());
				String clientRequest = inputStream.readUTF();
				DataOutputStream outputStream = new 
						DataOutputStream(socket.getOutputStream());
				System.out.println(clientRequest);
				switch (clientRequest) {
				case ORDER:
					doOrder(inputStream, outputStream);
					break;
				case REFRESH:
					doRefresh(outputStream);
					break;
				default:
					// TODO exception handling thrown
					break;
				}
				inputStream.close();
				outputStream.close();
			} catch (IOException e) {
				// TODO: handle exception
				e.printStackTrace();
			} finally {
				if (socket != null) {
					try {
						socket.close();
					} catch (Exception e2) {
						// TODO: handle exception
						socket = null;
						e2.printStackTrace();
					}
				}
			}
			
		}
		
		private void doRefresh(DataOutputStream outputStream) throws IOException {
			System.out.println(getItemJson());
			outputStream.writeUTF(getItemJson());
		}
		
		private void doOrder(DataInputStream inputStream, 
							DataOutputStream outputStream) throws IOException {
			// TODO: Order Items
			outputStream.writeUTF("OK");
			String ordJson = inputStream.readUTF();
			System.out.println(ordJson);
			try {
				ArrayList<Order> orders = reader.parseOrder(ordJson);
			} catch (BadOrderException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
	
	public static void main(String[] args) {
		System.out.println("Order Server launched ...");
		OrderServer orderServer = new OrderServer();
		orderServer.init();
	}
}
