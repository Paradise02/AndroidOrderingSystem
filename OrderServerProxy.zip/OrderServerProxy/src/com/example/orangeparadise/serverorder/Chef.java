package com.example.orangeparadise.serverorder;

public class Chef extends Thread{
	OrderServer server;
	
	public Chef(OrderServer server) {
		// TODO Auto-generated constructor stub
		this.server = server;
	}
	
	@Override
	public void run() {
		// TODO Auto-generated method stub
		super.run();
	}
}
